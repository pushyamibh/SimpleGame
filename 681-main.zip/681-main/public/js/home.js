const createGameButton = document.getElementById("createGameButton");

createGameButton.addEventListener("click", () => {
  $(".ui .modal").modal("show");
});
